﻿using Microsoft.Extensions.Configuration;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Configuration;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    static IConfigurationRoot _configuration;  

    static void Main(string[] args)
    {
        LoadConfiguration();
        string connectionString = _configuration["MongoDB_ConnectionString"];
        string databaseName = _configuration["MongoDB_DatabaseName"];
        string collectionName = _configuration["MongoDB_CollectionName"];


        Console.WriteLine($"MongoDB Connection: {connectionString}");
        Console.WriteLine($"MongoDB Connection - Database: {databaseName}");
        Console.WriteLine($"MongoDB Connection - CollectionName: {collectionName}");



        var client = new MongoClient(connectionString);
        var database = client.GetDatabase(databaseName);
        var collection = database.GetCollection<BsonDocument>(collectionName);
        Console.WriteLine("Job has been Initiated");

        BsonDocument resumeToken = LoadResumeToken();  // Load the last resume token

        var pipeline = new EmptyPipelineDefinition<ChangeStreamDocument<BsonDocument>>()
                            .Match("{ operationType: { $in: [ 'insert', 'update', 'replace', 'delete' ] } }");

        var options = new ChangeStreamOptions { StartAfter = resumeToken };  // Resume from last event

        using (var cursor = collection.Watch(pipeline, options))
        {
            foreach (var change in cursor.ToEnumerable())
            {
                BsonDocument bsonDoc = null;
                if (change.BackingDocument != null)
                    bsonDoc = change.BackingDocument;
                else if (change.FullDocument != null)
                    bsonDoc = change.FullDocument;

                    Console.WriteLine($"Change detected: {bsonDoc}");
                    SaveResumeToken(change.ResumeToken);  // Save the latest resume token
                // Send the change data to Azure Function
                SendToAzureFunction(bsonDoc).Wait();
            }
        }
    }

    static void SaveResumeToken(BsonDocument token)
    {
        string path = GetFilePath();
        System.IO.File.WriteAllText(path, token.ToJson());
        Console.WriteLine("Saved a new Token");
    }

    static BsonDocument LoadResumeToken()
    {
        string path = GetFilePath();
        if (System.IO.File.Exists(path))
        {
            string json = System.IO.File.ReadAllText(path);
            
            Console.WriteLine($"LoadResumeToken: {path}  --> {json}");
            return BsonDocument.Parse(json);
        }
        Console.WriteLine("LoadResumeToken: " + path);
        return null;  // Start from the latest changes
    }

    static async Task SendToAzureFunction(BsonDocument change)
    {
        string url = _configuration["AzureFunctionAppUrl"];
        using (var client = new HttpClient())
        {
            var content = new StringContent(change.ToJson(), System.Text.Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            Console.WriteLine("Response from Azure Function: " + response.StatusCode);
        }
    }
    static void LoadConfiguration()
    {
        var builder = new ConfigurationBuilder();

        // Read from appsettings.json (local)
        string path = Directory.GetCurrentDirectory();
        builder.SetBasePath(path)
               .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);

        // Read from environment variables (Azure WebJobs)
        builder.AddEnvironmentVariables();

        _configuration =  builder.Build();
    }

    static string GetFilePath()
    {
        return Path.Combine(Environment.GetEnvironmentVariable("HOME") ?? "D:\\home\\data", "resume_token.json");
    }


    //static async Task Main(string[] args)
    //{

    //      const string connectionUri = "mongodb+srv://chnagaraju009:meVLTMtlcOW45Twi@cluster1.w71oy.mongodb.net/myDatabase?retryWrites=true&w=majority&appName=Cluster1&connectTimeoutMS=60000";

    //    Console.WriteLine("Job has been Initited");

    //    var client = new MongoClient(connectionUri);
    //    var database = client.GetDatabase("sample_weatherdata");
    //    var collection = database.GetCollection<BsonDocument>("data");

    //    var pipeline = new EmptyPipelineDefinition<ChangeStreamDocument<BsonDocument>>()
    //        .Match("{ operationType: { $in: [ 'insert', 'update', 'replace', 'delete' ] } }");

    //    var options = new ChangeStreamOptions { FullDocument = ChangeStreamFullDocumentOption.UpdateLookup };

    //    using (var cursor = await collection.WatchAsync(pipeline, options))
    //    {
    //        await cursor.ForEachAsync(change =>
    //        {
    //            Console.WriteLine("Change detected: " + change.FullDocument);
    //            // Send the change data to Azure Function
    //            SendToAzureFunction(change.FullDocument).Wait();
    //        });
    //    }
    //}


}